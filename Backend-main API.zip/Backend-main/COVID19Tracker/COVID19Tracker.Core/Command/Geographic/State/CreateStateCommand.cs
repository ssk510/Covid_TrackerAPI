﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class CreateStateCommand : IRequest<State>
    {
        public State _State { get; }
        public CreateStateCommand(State State)
        {
            _State = State;
        }
    }
}
