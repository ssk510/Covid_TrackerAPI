﻿using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class DeleteStateCommand: IRequest<bool>
    {
        public string _Id { get; }
        public DeleteStateCommand(string Id)
        {
            _Id = Id;
        }
    }
}
