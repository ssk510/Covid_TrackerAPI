﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class UpdateStateCommand : IRequest<State>
    {
        public State _State { get; }
        public string _Id { get; }

        public UpdateStateCommand(State State, string Id)
        {
            _State = State;
            _Id = Id;
        }
    }
}
