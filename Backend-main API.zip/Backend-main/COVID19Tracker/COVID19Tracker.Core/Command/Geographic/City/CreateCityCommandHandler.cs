﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class CreateCityCommandHandler: IRequestHandler<CreateCityCommand, City>
    {
        private readonly IGeographicService _geographicService;
        public CreateCityCommandHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }
        public async Task<City> Handle(CreateCityCommand request, CancellationToken cancellationToken)
        {
            return await _geographicService.AddCity(request._City);
        }
    }
}
