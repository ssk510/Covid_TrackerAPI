﻿using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class DeleteCityCommand : IRequest<bool>
    {
        public string _Id { get; }
        public DeleteCityCommand(string Id)
        {
            _Id = Id;
        }
    }
}
