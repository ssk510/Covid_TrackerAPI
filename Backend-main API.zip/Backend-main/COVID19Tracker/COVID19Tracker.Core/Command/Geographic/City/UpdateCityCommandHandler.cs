﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class UpdateCityCommandHandler : IRequestHandler<UpdateCityCommand, City>
    {
        private readonly IGeographicService _geographicService;

        public UpdateCityCommandHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }
        public async Task<City> Handle(UpdateCityCommand request, CancellationToken cancellationToken)
        {
            return await _geographicService.UpdateCity(request._City, request._Id);
        }
    }
}
