﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class CreateCityCommand : IRequest<City>
    {
        public City _City { get; }
        public CreateCityCommand(City City)
        {
            _City = City;
        }
    }
}
