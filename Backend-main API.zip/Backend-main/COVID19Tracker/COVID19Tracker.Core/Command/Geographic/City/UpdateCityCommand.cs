﻿using COVID19Tracker.Core.Entities;
using MediatR;


namespace COVID19Tracker.Core.Command
{
    public class UpdateCityCommand : IRequest<City>
    {
        public City _City { get; }
        public string _Id { get; }

        public UpdateCityCommand(City City, string Id)
        {
            _City = City;
            _Id = Id;
        }
    }
}
