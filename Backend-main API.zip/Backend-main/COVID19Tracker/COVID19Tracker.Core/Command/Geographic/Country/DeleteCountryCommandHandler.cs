﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class DeleteCountryCommandHandler : IRequestHandler<DeleteCountryCommand, bool>
    {
        private readonly IGeographicService _geographicService;

        public DeleteCountryCommandHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }
        public async Task<bool> Handle(DeleteCountryCommand request, CancellationToken cancellationToken)
        {
            return await _geographicService.DeleteCountry(request._Id);
        }
    }
}
