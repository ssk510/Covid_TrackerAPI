﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
   public class CreateCountryCommandHandler : IRequestHandler<CreateCountryCommand, Country>
    {
        private readonly IGeographicService _geographicService;
        public CreateCountryCommandHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }
        public async Task<Country> Handle(CreateCountryCommand request, CancellationToken cancellationToken)
        {
            return await _geographicService.AddCountry(request._Country);
        }
    }
}
