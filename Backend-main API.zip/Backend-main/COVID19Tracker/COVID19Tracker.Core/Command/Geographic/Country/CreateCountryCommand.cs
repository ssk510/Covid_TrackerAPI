﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class CreateCountryCommand : IRequest<Country>
    {
        public Country _Country { get; }
        public CreateCountryCommand(Country Country)
        {
            _Country = Country;
        }
        
    }
}
