﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class UpdateCountryCommandHandler : IRequestHandler<UpdateCountryCommand, Country>
    {
        private readonly IGeographicService _geographicService;

        public UpdateCountryCommandHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }
        public async Task<Country> Handle(UpdateCountryCommand request, CancellationToken cancellationToken)
        {
            return await _geographicService.UpdateCountry(request._Country, request._Id);
        }
    }
}
