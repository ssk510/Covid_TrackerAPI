﻿using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class DeleteCountryCommand: IRequest<bool>
    {
        public string _Id { get; }
        public DeleteCountryCommand(string Id)
        {
            _Id = Id;
        }
    }
}
