﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class DeleteCovidInfoCommandHandler : IRequestHandler<DeleteCovidInfoCommand, bool>
    {
        private readonly ICovidInfoService _covidinfoService;

        public DeleteCovidInfoCommandHandler(ICovidInfoService covidinfoService)
        {
            _covidinfoService = covidinfoService;
        }
        public async Task<bool> Handle(DeleteCovidInfoCommand request, CancellationToken cancellationToken)
        {
            return await _covidinfoService.DeleteInfo(request._Id);
        }
    }
}
