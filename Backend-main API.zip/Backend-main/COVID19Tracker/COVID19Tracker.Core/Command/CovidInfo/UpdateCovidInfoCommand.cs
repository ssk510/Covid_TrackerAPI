﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class UpdateCovidInfoCommand : IRequest<CovidInfo>
    {
        public CovidInfo _CovidInfo { get;  }
        public string _Id { get; }
        public UpdateCovidInfoCommand(CovidInfo covidInfo, string Id)
        {
            _CovidInfo = covidInfo;
            _Id = Id;
        }
    }
}
