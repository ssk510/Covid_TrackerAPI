﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;


namespace COVID19Tracker.Core.Command
{
    public class UpdateCovidInfoCommandHandler : IRequestHandler<UpdateCovidInfoCommand, CovidInfo>
    {
        private readonly ICovidInfoService _covidinfoService;

        public UpdateCovidInfoCommandHandler(ICovidInfoService covidinfoService)
        {
            _covidinfoService = covidinfoService;
        }
        public async Task<CovidInfo> Handle(UpdateCovidInfoCommand request, CancellationToken cancellationToken)
        {
            return await _covidinfoService.UpdateInfo(request._CovidInfo, request._Id);
        }
    }
}
