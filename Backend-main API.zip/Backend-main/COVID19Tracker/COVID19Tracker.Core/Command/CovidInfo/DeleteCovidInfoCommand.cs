﻿using MediatR;


namespace COVID19Tracker.Core.Command
{
    public class DeleteCovidInfoCommand : IRequest<bool>
    {
        public string _Id { get; }
        public DeleteCovidInfoCommand(string Id)
        {
            _Id = Id;
        }
    }
}
