﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class CreateCovidInfoCommand : IRequest<CovidInfo>
    {
        public CovidInfo _CovidInfo { get; set; }
        public CreateCovidInfoCommand(CovidInfo CovidInfo)
        {
            _CovidInfo = CovidInfo;
        }
    }
}
