﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Command
{
    public class CreateCovidInfoCommandHandler : IRequestHandler<CreateCovidInfoCommand, CovidInfo>
    {
        private readonly ICovidInfoService _covidinfoService;
        public CreateCovidInfoCommandHandler(ICovidInfoService covidinfoService)
        {
            _covidinfoService = covidinfoService;
        }
        public async Task<CovidInfo> Handle(CreateCovidInfoCommand request, CancellationToken cancellationToken)
        {
            return await _covidinfoService.AddInfo(request._CovidInfo);
        }
    }
}
