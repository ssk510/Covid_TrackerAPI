﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetStateQueryHandler : IRequestHandler<GetStateQuery, IEnumerable<State>>
    {
        private readonly IGeographicService _geographicService;

        public GetStateQueryHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }

        public async Task<IEnumerable<State>> Handle(GetStateQuery request, CancellationToken cancellationToken)
        {
            return await _geographicService.GetAllState();
        }
    }
}
