﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetStateByIdQuery: IRequest<State>
    {
        public string _StateId { get; set; }

        public GetStateByIdQuery(string StateId)
        {
            _StateId = StateId;
        }
    }
}
