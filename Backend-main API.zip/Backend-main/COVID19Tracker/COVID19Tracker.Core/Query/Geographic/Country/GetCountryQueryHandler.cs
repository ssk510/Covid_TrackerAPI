﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCountryQueryHandler : IRequestHandler<GetCountryQuery, IEnumerable<Country>>
    {
        private readonly IGeographicService _geographicService;

        public GetCountryQueryHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }

        public async Task<IEnumerable<Country>> Handle(GetCountryQuery request, CancellationToken cancellationToken)
        {
            return await _geographicService.GetAllCountry();
        }
    }
}
