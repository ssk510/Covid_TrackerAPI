﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCountryByIdQueryHandler : IRequestHandler<GetCountryByIdQuery, Country>
    {
        private readonly IGeographicService _geographicService;

        public GetCountryByIdQueryHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }

        public async Task<Country> Handle(GetCountryByIdQuery request, CancellationToken cancellationToken)
        {
            return await _geographicService.GetCountryById(request._CountryId);
        }

    }
}
