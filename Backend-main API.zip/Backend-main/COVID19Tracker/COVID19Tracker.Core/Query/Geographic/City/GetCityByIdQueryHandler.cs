﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCityByIdQueryHandler : IRequestHandler<GetCityByIdQuery, City>
    {
        private readonly IGeographicService _geographicService;
        public GetCityByIdQueryHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }

        public async Task<City> Handle(GetCityByIdQuery request, CancellationToken cancellationToken)
        {
            return await _geographicService.GetCityById(request._CityId);
        }
    }
}
