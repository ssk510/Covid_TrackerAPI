﻿using COVID19Tracker.Core.Entities;
using MediatR;


namespace COVID19Tracker.Core.Query
{
    public class GetCityByIdQuery : IRequest<City>
    {
        public string _CityId { get; }
        public GetCityByIdQuery(string CityId)
        {
            _CityId = CityId;
        }
    }
}
