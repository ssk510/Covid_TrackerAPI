﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCityQueryHandler : IRequestHandler<GetCityQuery, IEnumerable<City>>
    {
        private readonly IGeographicService _geographicService;

        public GetCityQueryHandler(IGeographicService geographicService)
        {
            _geographicService = geographicService;
        }

        public async Task<IEnumerable<City>> Handle(GetCityQuery request, CancellationToken cancellationToken)
        {
            return await _geographicService.GetAllCity();
        }
    }
}
