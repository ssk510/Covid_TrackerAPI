﻿using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCovidInfoByIdQuery : IRequest<CovidInfo>
    {
        public string _InfoId { get; set; }
        public GetCovidInfoByIdQuery(string InfoId)
        {
            _InfoId = InfoId;
        }

    }
}
