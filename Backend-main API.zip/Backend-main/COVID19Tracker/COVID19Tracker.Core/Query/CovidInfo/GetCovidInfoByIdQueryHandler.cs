﻿using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCovidInfoByIdQueryHandler : IRequestHandler<GetCovidInfoByIdQuery, CovidInfo>
    {
        private readonly ICovidInfoService _covidinfoService;
        public GetCovidInfoByIdQueryHandler(ICovidInfoService covidinfoService)
        {
            _covidinfoService = covidinfoService;
        }

        public async Task<CovidInfo> Handle(GetCovidInfoByIdQuery request, CancellationToken cancellationToken)
        {
            return await _covidinfoService.GetInfoById(request._InfoId);
        }
    }
}
