﻿using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using MediatR;

namespace COVID19Tracker.Core.Query
{
    public class GetCovidInfoByGeoQueryHandler : IRequestHandler<GetCovidInfoByGeoQuery, IEnumerable<CovidInfo>>
    {
        private readonly ICovidInfoService _covidinfoService;
        public GetCovidInfoByGeoQueryHandler(ICovidInfoService covidinfoService)
        {
            _covidinfoService = covidinfoService;
        }

        public async Task<IEnumerable<CovidInfo>> Handle(GetCovidInfoByGeoQuery request, CancellationToken cancellationToken)
        {
            return await _covidinfoService.GetAllInfoByGeographic(request.CountryId, request.StateId, request.CityId);
        }
    }
}
