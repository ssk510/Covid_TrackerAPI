﻿namespace COVID19Tracker.Core.Contracts
{
    public interface IAdminService : IGeographicService, IUserService, ICovidInfoService
    {
    }
}
