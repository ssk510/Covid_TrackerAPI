﻿using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COVID19Tracker.Core.Services
{
    public class GeographicService : IGeographicService
    {
        private readonly IMongoCollection<Country> _country;
        private readonly IMongoCollection<State> _state;
        private readonly IMongoCollection<City> _city;
        private readonly IMongoClient _client;
        private readonly GeographicConfig _geographicConfig;

        public GeographicService(IOptionsMonitor<GeographicConfig> geographicConfig)
        {
            _geographicConfig = geographicConfig.CurrentValue;
            _client = new MongoClient(_geographicConfig.ConnectionString);
            var database = _client.GetDatabase(_geographicConfig.DatabaseName);

            _country = database.GetCollection<Country>(_geographicConfig.CollectionNames.CountryCollectioName);
            _state = database.GetCollection<State>(_geographicConfig.CollectionNames.StateCollectioName);
            _city = database.GetCollection<City>(_geographicConfig.CollectionNames.CityCollectioName);
        }

        public async Task<Country> AddCountry(Country country)
        {
            Country geoCountry = new Country();
            try
            {
                await _country.InsertOneAsync(country);
                var filter = Builders<Country>.Filter.Where(x => x.CountryId.ToLower().Contains(country.CountryId.ToLower()));
                geoCountry = await _country.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Adding geo country failed");
            }
            return geoCountry;
        }

        public async Task<Country> UpdateCountry(Country input, string countryId)
        {
            Country geoCountry = new Country();
            UpdateResult res = null;
            try
            {
                var filter = Builders<Country>.Filter.Where(x => x.CountryId.ToLower().Contains(countryId.ToLower()));
                geoCountry = await _country.Find(filter).FirstOrDefaultAsync();
                if (geoCountry != null)
                {
                    var update = Builders<Country>.Update
                        .Set(x => x.Name, input.Name)
                        .Set(x => x.IsActive, input.IsActive)
                        .Set(x => x.CreatedBy, geoCountry.CreatedBy)
                        .Set(x => x.CreatedDate, geoCountry.CreatedDate)
                        .Set(x => x.ModifiedBy, input.ModifiedBy)
                        .Set(x => x.ModifiedDate, input.ModifiedDate);
                    res = await _country.UpdateOneAsync(filter, update);
                }

            }
            catch (MongoException)
            {
             throw new Exception("Update Country failed");
            }
            var filter1 = Builders<Country>.Filter.Where(x => x.CountryId.ToLower().Contains(countryId.ToLower()));
            geoCountry = await _country.Find(filter1).FirstOrDefaultAsync();
            return geoCountry;
        }

        public async Task<bool> DeleteCountry(string countryId)
        {
            DeleteResult res = null;

            try
            {
                var filter = Builders<Country>.Filter.Where(x => x.CountryId.ToLower().Contains(countryId.ToLower()));
                res = await _country.DeleteOneAsync(filter);
            }
            catch (MongoException)
            {
                throw new Exception("No document found");
            }
            return (res.IsAcknowledged && res.DeletedCount > 0) ? true : false;
        }

        public async Task<IEnumerable<Country>> GetAllCountry()
        {
            return await _country.Find(new BsonDocument()).ToListAsync();
        }

        public async Task<Country> GetCountryById(string countryId)
        {
            Country rl = new Country();
            try
            {
                var filter = Builders<Country>.Filter.Where(x => x.CountryId.ToLower().Contains(countryId.ToLower()));
                rl = await _country.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Get country failed");
            }
            return rl;
        }

        public async Task<State> AddState(State state)
        {
            State geoState = new State();
            try
            {
                await _state.InsertOneAsync(state);
                var filter = Builders<State>.Filter.Where(x => x.StateId.ToLower().Contains(state.StateId.ToLower()));
                geoState = await _state.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Adding geo state failed");
            }
            return geoState;
        }

        public async Task<State> UpdateState(State input, string stateId)
        {
            State geoState = new State();
            UpdateResult res = null;
            try
            {
                var filter = Builders<State>.Filter.Where(x => x.StateId.ToLower().Contains(stateId.ToLower()));
                geoState = await _state.Find(filter).FirstOrDefaultAsync();
                if (geoState != null)
                {
                    var update = Builders<State>.Update
                        .Set(x => x.Name, input.Name)
                        .Set(x => x.CountryId, input.CountryId)
                        .Set(x => x.IsActive, input.IsActive)
                        .Set(x => x.CreatedBy, geoState.CreatedBy)
                        .Set(x => x.CreatedDate, geoState.CreatedDate)
                        .Set(x => x.ModifiedBy, input.ModifiedBy)
                        .Set(x => x.ModifiedDate, input.ModifiedDate);
                    res = await _state.UpdateOneAsync(filter, update);
                }

            }
            catch (MongoException)
            {
                throw new Exception("Update State failed");
            }
            var filter1 = Builders<State>.Filter.Where(x => x.StateId.ToLower().Contains(stateId.ToLower()));
            geoState = await _state.Find(filter1).FirstOrDefaultAsync();
            return geoState;
        }
        public async Task<bool> DeleteState(string stateId)
        {
            DeleteResult res = null;

            try
            {
                var filter = Builders<State>.Filter.Where(x => x.StateId.ToLower().Contains(stateId.ToLower()));
                res = await _state.DeleteOneAsync(filter);
            }
            catch (MongoException)
            {
                throw new Exception("No document found");
            }
            return (res.IsAcknowledged && res.DeletedCount > 0) ? true : false;
        }
        public async Task<IEnumerable<State>> GetAllState()
        {
            return await _state.Find(new BsonDocument()).ToListAsync();
        }
        public async Task<State> GetStateById(string stateId)
        {
            State rl = new State();
            try
            {
                var filter = Builders<State>.Filter.Where(x => x.StateId.ToLower().Contains(stateId.ToLower()));
                rl = await _state.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Get State failed");
            }
            return rl;
        }
        public async Task<City> AddCity(City city)
        {
            City geoCity = new City();
            try
            {
                await _city.InsertOneAsync(city);
                var filter = Builders<City>.Filter.Where(x => x.CityId.ToLower().Contains(city.CityId.ToLower()));
                geoCity = await _city.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Adding geo city failed");
            }
            return geoCity;
        }
        public async Task<City> UpdateCity(City input, string cityId)
        {
            City geoCity = new City();
            UpdateResult res = null;
            try
            {
                var filter = Builders<City>.Filter.Where(x => x.CityId.ToLower().Contains(cityId.ToLower()));
                geoCity = await _city.Find(filter).FirstOrDefaultAsync();
                if (geoCity != null)
                {
                    var update = Builders<City>.Update
                        .Set(x => x.Name, input.Name)
                        .Set(x => x.CountryId, input.CountryId)
                        .Set(x => x.StateId, input.StateId)
                        .Set(x => x.IsActive, input.IsActive)
                        .Set(x => x.CreatedBy, geoCity.CreatedBy)
                        .Set(x => x.CreatedDate, geoCity.CreatedDate)
                        .Set(x => x.ModifiedBy, input.ModifiedBy)
                        .Set(x => x.ModifiedDate, input.ModifiedDate);
                    res = await _city.UpdateOneAsync(filter, update);
                }

            }
            catch (MongoException)
            {
                throw new Exception("Update City failed");
            }
            var filter1 = Builders<City>.Filter.Where(x => x.CityId.ToLower().Contains(cityId.ToLower()));
            geoCity = await _city.Find(filter1).FirstOrDefaultAsync();
            return geoCity;
        }
        public async Task<bool> DeleteCity(string cityId)
        {
            DeleteResult res = null;

            try
            {
                var filter = Builders<City>.Filter.Where(x => x.CityId.ToLower().Contains(cityId.ToLower()));
                res = await _city.DeleteOneAsync(filter);
            }
            catch (MongoException)
            {
                throw new Exception("No document found");
            }
            return (res.IsAcknowledged && res.DeletedCount > 0) ? true : false;
        }
        public async Task<IEnumerable<City>> GetAllCity()
        {
            return await _city.Find(new BsonDocument()).ToListAsync();
        }
        public async Task<City> GetCityById(string cityId)
        {
            City rl = new City();
            try
            {
                var filter = Builders<City>.Filter.Where(x => x.CityId.ToLower().Contains(cityId.ToLower()));
                rl = await _city.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Get City failed");
            }
            return rl;
        }
    }
}

