﻿using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Entities;
using Microsoft.Extensions.Options;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COVID19Tracker.Core.Services
{
    public class CovidInfoService : ICovidInfoService
    {
        private readonly IMongoCollection<CovidInfo> _covidinfo;
        private readonly IMongoClient _client;
        private readonly CovidConfig _covidConfig;

        public CovidInfoService(IOptionsMonitor<CovidConfig> covidConfig)
        {
            _covidConfig = covidConfig.CurrentValue;
            _client = new MongoClient(_covidConfig.ConnectionString);
            var database = _client.GetDatabase(_covidConfig.DatabaseName);

            _covidinfo = database.GetCollection<CovidInfo>(_covidConfig.CollectionName);
        }

        public async Task<CovidInfo> AddInfo(CovidInfo user)
        {
            CovidInfo covidInfo = new CovidInfo();
            try
            {
                await _covidinfo.InsertOneAsync(user);
                var filter = Builders<CovidInfo>.Filter.Where(x => x.InfoId.ToLower().Contains(covidInfo.InfoId.ToLower()));
                covidInfo = await _covidinfo.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Adding Covid Info failed");
            }
            return covidInfo;
        }

        public async Task<CovidInfo> UpdateInfo(CovidInfo input, string infoId)
        {
            CovidInfo covidInfo = new CovidInfo();
            UpdateResult res = null;
            try
            {
                var filter = Builders<CovidInfo>.Filter.Where(x => x.InfoId.ToLower().Contains(infoId.ToLower()));
                covidInfo = await _covidinfo.Find(filter).FirstOrDefaultAsync();
                if (covidInfo != null)
                {
                    var update = Builders<CovidInfo>.Update
                        .Set(x => x.CountryId, input.CountryId)
                        .Set(x => x.StateId, input.StateId)
                        .Set(x => x.CityId, input.CityId)
                        .Set(x => x.IsTested, input.IsTested)
                        .Set(x => x.IsConfirmed, input.IsConfirmed)
                        .Set(x => x.IsQuarantined, input.IsQuarantined)
                        .Set(x => x.IsRecovered, input.IsRecovered)
                        .Set(x => x.IsDeceased, input.IsDeceased)
                        .Set(x => x.CreatedBy, covidInfo.CreatedBy)
                        .Set(x => x.CreatedDate, covidInfo.CreatedDate)
                        .Set(x => x.ModifiedBy, input.ModifiedBy)
                        .Set(x => x.ModifiedDate, input.ModifiedDate);
                    res = await _covidinfo.UpdateOneAsync(filter, update);
                }

            }
            catch (MongoException)
            {
                throw new Exception("Update CovidInfo failed");
            }
            var filter1 = Builders<CovidInfo>.Filter.Where(x => x.InfoId.ToLower().Contains(infoId.ToLower()));
            covidInfo = await _covidinfo.Find(filter1).FirstOrDefaultAsync();
            return covidInfo;
        }

        public async Task<bool> DeleteInfo(string infoId)
        {
            DeleteResult res = null;

            try
            {
                var filter = Builders<CovidInfo>.Filter.Where(x => x.InfoId.ToLower().Contains(infoId.ToLower()));
                res = await _covidinfo.DeleteOneAsync(filter);
            }
            catch (MongoException)
            {
                throw new Exception("No document found");
            }
            return (res.IsAcknowledged && res.DeletedCount > 0) ? true : false;
        }

        public async Task<IEnumerable<CovidInfo>> GetAllInfo()
        {
            return await _covidinfo.Find(new BsonDocument()).ToListAsync();
        }
        public async Task<CovidInfo> GetInfoById(string infoId)
        {
            CovidInfo rl = new CovidInfo();
            try
            {
                var filter = Builders<CovidInfo>.Filter.Where(x => x.InfoId.ToLower().Contains(infoId.ToLower()));
                rl = await _covidinfo.Find(filter).FirstOrDefaultAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Get covidinfo failed");
            }
            return rl;
        }
        public async Task<IEnumerable<CovidInfo>> GetAllInfoByGeographic(string? countryId, string? stateId, string? cityId)
        {
            IEnumerable<CovidInfo> rl;
            try
            {
                var filter = Builders<CovidInfo>.Filter.Where(x => x.CountryId.ToLower().Contains(countryId.ToLower()) &&
                x.StateId.ToLower().Contains(stateId.ToLower()) && x.CityId.ToLower().Contains(cityId.ToLower()));
                rl = await _covidinfo.Find(filter).ToListAsync();
            }
            catch (MongoException)
            {
                throw new Exception("Get covidinfo failed");
            }
            return rl;
        }
    }
}
