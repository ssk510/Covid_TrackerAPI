﻿namespace COVID19Tracker.Auth
{
    public class AppUserRole
    {
        public string UserRoleId { get; set; }
        public string UserId { get; set; }
        public string RoleId { get; set; }
        public bool IsActive { get; set; }
    }
}
