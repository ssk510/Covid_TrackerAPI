﻿namespace COVID19Tracker.Auth
{
    public class AppRole
    {
        public string RoleId { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
    }
}
