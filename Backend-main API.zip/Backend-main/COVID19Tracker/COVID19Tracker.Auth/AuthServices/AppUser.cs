﻿namespace COVID19Tracker.Auth
{
    public class AppUser
    {
        public string SubjectId { get; set; }
        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int Phone { get; set; }
        public bool IsActive { get; set; }
    }
}
