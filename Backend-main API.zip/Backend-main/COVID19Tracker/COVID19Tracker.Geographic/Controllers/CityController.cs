﻿using COVID19Tracker.Core.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using COVID19Tracker.Core.Query;
using Microsoft.AspNetCore.Authorization;
using COVID19Tracker.Core.Command;

namespace COVID19Tracker.Geographic.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class CityController : ControllerBase
    {
        private readonly IMediator _mediator;
        public CityController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet, Route("GetAllCity")]
        [Authorize(Policy = "UserSecure")]
        public async Task<IEnumerable<City>> GetAllCityAsync()
        {
            return await _mediator.Send(new GetCityQuery());
        }

        [HttpGet, Route("GetCityById")]
        [Authorize(Policy = "UserSecure")]
        public async Task<City> GetCityByIdAsync(string cityId)
        {
            return await _mediator.Send(new GetCityByIdQuery(cityId));
        }

        [HttpGet, Route("AddCity")]
        [Authorize(Policy = "UserSecure")]
        public async Task<City> AddCity(City city)
        {
            return await _mediator.Send(new CreateCityCommand(city));
        }

        [HttpGet, Route("UpdateCity")]
        [Authorize(Policy = "UserSecure")]
        public async Task<City> UpdateCity(City input, string cityId)
        {
            return await _mediator.Send(new UpdateCityCommand(input, cityId));
        }

        [HttpGet, Route("DeleteCity")]
        [Authorize(Policy = "UserSecure")]
        public async Task<bool> DeleteCity(string cityId)
        {
            return await _mediator.Send(new DeleteCityCommand(cityId));
        }
    }
}
