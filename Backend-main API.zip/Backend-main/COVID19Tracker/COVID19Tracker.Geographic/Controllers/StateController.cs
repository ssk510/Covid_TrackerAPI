﻿using COVID19Tracker.Core.Command;
using COVID19Tracker.Core.Entities;
using COVID19Tracker.Core.Query;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace COVID19Tracker.Geographic.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class StateController : ControllerBase
    {
        private readonly IMediator _mediator;
        public StateController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet, Route("GetAllState")]
        [Authorize(Policy = "UserSecure")]
        public async Task<IEnumerable<State>> GetAllStateAsync()
        {
            return await _mediator.Send(new GetStateQuery());
        }

        [HttpGet, Route("GetAllStateById")]
        [Authorize(Policy = "UserSecure")]
        public async Task<State> GetStateByIdAsync(string stateId)
        {
            return await _mediator.Send(new GetStateByIdQuery(stateId));
        }

        [HttpGet, Route("AddState")]
        [Authorize(Policy = "UserSecure")]
        public async Task<State> AddState(State state)
        {
            return await _mediator.Send(new CreateStateCommand(state));
        }

        [HttpGet, Route("UpdateState")]
        [Authorize(Policy = "UserSecure")]
        public async Task<State> UpdateState(State input, string stateId)
        {
            return await _mediator.Send(new UpdateStateCommand(input, stateId));
        }

        [HttpGet, Route("DeleteState")]
        [Authorize(Policy = "UserSecure")]
        public async Task<bool> DeleteState(string stateId)
        {
            return await _mediator.Send(new DeleteStateCommand(stateId));
        }
    }
}
