﻿using COVID19Tracker.Core.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using COVID19Tracker.Core.Query;
using Microsoft.AspNetCore.Authorization;
using COVID19Tracker.Core.Command;

namespace COVID19Tracker.Geographic.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class CountryController : ControllerBase
    {
        private readonly IMediator _mediator;
        public CountryController(IMediator mediator)
        {
            _mediator = mediator;
        }
        
        [HttpGet,Route("GetAllCountries")]
        [Authorize(Policy = "UserSecure")]
        public async Task<IEnumerable<Country>> GetCountryAsync()
        {
            return await _mediator.Send(new GetCountryQuery());           
        }

        [HttpGet, Route("GetAllCountriesById")]
        [Authorize(Policy = "UserSecure")]
        public async Task<Country> GetCountryByIdAsync(string countryId)
        {
            return await _mediator.Send(new GetCountryByIdQuery(countryId));
        }

        [HttpGet, Route("AddCountry")]
        [Authorize(Policy = "UserSecure")]
        public async Task<Country> AddCountry(Country country)
        {
            return await _mediator.Send(new CreateCountryCommand(country));
        }

        [HttpGet, Route("UpdateCountry")]
        [Authorize(Policy = "UserSecure")]
        public async Task<Country> UpdateCountry(Country input, string countryId)
        {
            return await _mediator.Send(new UpdateCountryCommand(input, countryId));
        }

        [HttpGet, Route("DeleteCountry")]
        [Authorize(Policy = "UserSecure")]
        public async Task<bool> DeleteCountry(string countryId)
        {
            return await _mediator.Send(new DeleteCountryCommand(countryId));
        }
    }
}
