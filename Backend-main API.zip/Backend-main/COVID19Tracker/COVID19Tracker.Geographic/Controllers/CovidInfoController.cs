﻿using COVID19Tracker.Core.Entities;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using COVID19Tracker.Core.Query;
using Microsoft.AspNetCore.Authorization;
using COVID19Tracker.Core.Command;

namespace COVID19Tracker.Geographic.Controllers
{
    [ApiVersion("1")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [ApiController]
    public class CovidInfoController : ControllerBase
    {
        private readonly IMediator _mediator;
        public CovidInfoController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet, Route("GetAllCovidInfo")]
        [Authorize(Policy = "UserSecure")]
        public async Task<IEnumerable<CovidInfo>> GetAllCovidInfoAsync()
        {
            return await _mediator.Send(new GetCovidInfoQuery());
        }

        [HttpGet, Route("GetAllCovidInfoById")]
        [Authorize(Policy = "UserSecure")]
        public async Task<CovidInfo> GetCovidInfoByIdAsync(string InfoId)
        {
            return await _mediator.Send(new GetCovidInfoByIdQuery(InfoId));
        }

        [HttpGet, Route("AddCovidInfo")]
        [Authorize(Policy = "UserSecure")]
        public async Task<CovidInfo> AddCovidInfo(CovidInfo CovidInfo)
        {
            return await _mediator.Send(new CreateCovidInfoCommand(CovidInfo));
        }

        [HttpGet, Route("UpdateCovidInfo")]
        [Authorize(Policy = "UserSecure")]
        public async Task<CovidInfo> UpdateCovidInfo(CovidInfo input, string InfoId)
        {
            return await _mediator.Send(new UpdateCovidInfoCommand(input, InfoId));
        }

        [HttpGet, Route("DeleteCovidInfo")]
        [Authorize(Policy = "UserSecure")]
        public async Task<bool> DeleteCovidInfo(string InfoId)
        {
            return await _mediator.Send(new DeleteCovidInfoCommand(InfoId));
        }
    }
}
