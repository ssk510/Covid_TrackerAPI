using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using System.Reflection;
using IdentityServer4.AccessTokenValidation;
using Microsoft.OpenApi.Models;
using COVID19Tracker.Core.Services;
using COVID19Tracker.Core.Contracts;
using COVID19Tracker.Core.Query;
using COVID19Tracker.Core.Entities;
using COVID19Tracker.Core.Command;

namespace COVID19Tracker.Geographic
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var policy = new Microsoft.AspNetCore.Cors.Infrastructure.CorsPolicy();

            policy.Headers.Add("*");
            policy.Methods.Add("*");
            policy.Origins.Add("*");
            policy.SupportsCredentials = true;

            services.AddCors(x => x.AddPolicy("corsGlobalPolicy", policy));
            var geographicConfig = Configuration.GetSection("GeographicConfig");
            services.Configure<GeographicConfig>(geographicConfig);

            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = IdentityServerAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = IdentityServerAuthenticationDefaults.AuthenticationScheme;
            }).AddIdentityServerAuthentication(options =>
            {
                options.Authority = Configuration["IdentityServer:Authority"];
                options.ApiName = "geographicapi";
                options.ApiSecret = Configuration["IdentityServer:ClientSecret"];
                options.RequireHttpsMetadata = true;
            });
            services.AddAuthorization(options =>
            {
                options.AddPolicy("PublicSecure", policyUser =>
                {
                    policyUser.RequireClaim("client_id", Configuration["IdentityServer:ClientId"]);
                });
                options.AddPolicy("UserSecure", policy =>
                policy.RequireClaim("role", "user"));

                options.AddPolicy("AdminSecure", policy =>
                policy.RequireClaim("role", "admin"));
            });
            services.AddMediatR(Assembly.GetExecutingAssembly());
            services.AddTransient<IGeographicService, GeographicService>();
            services.AddTransient<IRequestHandler<GetCountryQuery,IEnumerable<Country>>, GetCountryQueryHandler>();
            services.AddTransient<IRequestHandler<GetCountryByIdQuery, Country>, GetCountryByIdQueryHandler>();
            services.AddTransient<IRequestHandler<CreateCountryCommand, Country>, CreateCountryCommandHandler>();
            services.AddTransient<IRequestHandler<UpdateCountryCommand, Country>, UpdateCountryCommandHandler>();
            services.AddTransient<IRequestHandler<DeleteCountryCommand, bool>, DeleteCountryCommandHandler>();
            services.AddTransient<IRequestHandler<GetStateQuery,IEnumerable<State>>, GetStateQueryHandler>();
            services.AddTransient<IRequestHandler<GetStateByIdQuery, State>, GetStateByIdQueryHandler>();
            services.AddTransient<IRequestHandler<CreateStateCommand, State>, CreateStateCommandHandler>();
            services.AddTransient<IRequestHandler<UpdateStateCommand, State>, UpdateStateCommandHandler>();
            services.AddTransient<IRequestHandler<DeleteStateCommand, bool>, DeleteStateCommandHandler>();
            services.AddTransient<IRequestHandler<GetCityQuery, IEnumerable<City>>, GetCityQueryHandler>();
            services.AddTransient<IRequestHandler<GetCityByIdQuery, City>, GetCityByIdQueryHandler>();
            services.AddTransient<IRequestHandler<CreateCityCommand, City>, CreateCityCommandHandler>();
            services.AddTransient<IRequestHandler<UpdateCityCommand, City>, UpdateCityCommandHandler>();
            services.AddTransient<IRequestHandler<DeleteCityCommand, bool>, DeleteCityCommandHandler>();
            services.AddControllers();           
            services.AddHttpContextAccessor();
            services.AddApiVersioning();
            services.AddVersionedApiExplorer(options =>
            {
                options.GroupNameFormat = "'v'VVV";
                options.SubstituteApiVersionInUrl = true;
            });
            services.AddSwaggerGen(c =>
            {
                var apiinfo = new OpenApiInfo
                {
                    Title = "COVID19 Tracker Geographic API",
                    Version = "v1",
                    Description = "COVID19 Tracker Geographic API",
                    Contact = new OpenApiContact
                    { Name = "Arulprakash", Email = "arulprakash.s@cognizant.com" },
                    License = new OpenApiLicense()
                    {
                        Name = "GNU"
                    }
                };

                OpenApiSecurityScheme securityDefinition = new OpenApiSecurityScheme()
                {
                    Name = "Resource Owner Password flow",
                    Scheme = IdentityServerAuthenticationDefaults.AuthenticationScheme,
                    Description = "Specify the user name and password.",
                    Type = SecuritySchemeType.OAuth2,
                    Flows = new OpenApiOAuthFlows
                    {
                        Password = new OpenApiOAuthFlow
                        {
                            TokenUrl = new Uri(Configuration["IdentityServer:TokenUrl"]),
                            Scopes = new Dictionary<string, string>
                            {
                                {"geographicapi", "full access"}
                            }
                        }
                    }
                };
                c.AddSecurityDefinition("oauth2", securityDefinition);
                c.OperationFilter<SecureEndpointAuthRequirementFilter>();
                c.SwaggerDoc("v1", apiinfo);
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            app.UseCors("corsGlobalPolicy");
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "COVID19 Tracker Geographic API V1");
                c.RoutePrefix = "";
                c.OAuthClientId(Configuration["IdentityServer:ClientId"]);
                c.OAuthClientSecret(Configuration["IdentityServer:ClientSecret"]);
                c.OAuthUsername("user");
                c.OAuthScopes(new string[] { "geographicapi" });
                c.OAuthAppName("COVID19 Tracker Geographic API - Swagger");
            });
        }
    }
}
