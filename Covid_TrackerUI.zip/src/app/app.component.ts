import { Component, OnInit, ViewChild } from '@angular/core';
import { NavigationStart, Router, RouterEvent } from '@angular/router';
import { ModalDirective } from 'angular-bootstrap-md';
import { Auth } from 'aws-amplify';
import { from, interval } from 'rxjs';
import { AuthService } from './services/auth.service';
import { FormvalidationService } from './services/validators.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  public loggerUser: any = null;
  public isUserLoggedIn: boolean = false;
  public expireSeconds: number = 120000 / 1000;
  @ViewChild('sessionExpiryModal', { static: false, read: ModalDirective }) sessionExpiryModal: ModalDirective;

  public mHome:boolean=false;
  public mUser:boolean=false;
  public mCountry:boolean=false;
  public mState:boolean=false;
  public mCity:boolean=false;
  public mCovidinfo:boolean=false;
  private flag:any;

  constructor(private authService: AuthService,
    private router: Router,private mvalidation:FormvalidationService) {

      this.mvalidation.getValue().subscribe((value) => {
        this.flag = value;
        if(this.flag){
        this.mHome=true;
        this.mUser=true;
        this.mCountry=true;
        this.mState=true;
        this.mCity=true;
        this.mCovidinfo=true;
        }
      });
  }

  ngOnInit() {
   
  }

  continue(event: Event) {
   
  }

  signout(event: Event) {
    if (event)
      event.preventDefault();
    this.authService.signOut().then((res: boolean) => {
      if (res) {
        this.loggerUser = null;
        this.router.navigate(['signin']);
      }
    });
  }
}
