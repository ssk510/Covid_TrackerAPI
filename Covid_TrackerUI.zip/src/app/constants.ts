export const Constants = {
    getAllCountryEndpoint: 'api/v1/Geographic/country/getall',
    getAllStateEndpoint: 'api/v1/Geographic/state/getall',
    getAllCityEndpoint: 'api/v1/Geographic/city/getall',
    addCountryEndpoint: 'api/v1/Geographic/country/add',
    addStateEndpoint: 'api/v1/Geographic/state/add',
    addCityEndpoint: 'api/v1/Geographic/city/add',
    deleteCountryEndpoint: 'api/v1/Geographic/country/delete',
    deleteStateEndpoint: 'api/v1/Geographic/state/delete',
    deleteCityEndpoint: 'api/v1/Geographic/city/delete',
    getAllCovidInfoEndpoint: 'api/v1/Geographic/CovidInfo/delete',
    addCovidInfoEndpoint: 'api/v1/Geographic/CovidInfo/delete',
    deleteCovidInfoEndpoint: 'api/v1/Geographic/CovidInfo/delete'
}