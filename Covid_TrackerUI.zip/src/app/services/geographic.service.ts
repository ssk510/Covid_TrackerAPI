import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { Constants } from '../constants';
import { CompanyDetails, Stock, StockAddVM, StockGetVM } from '../models/company.model';
import { Country,State,City,CovidInfo } from '../models/geographic.model';

@Injectable()
export class geographicService {

  constructor(@Inject("gatewayAPIRoot") private GATEWAY_API_ROOT, private http: HttpClient) { }

  public getAllCountry(): Observable<Country[]> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.getAllCountryEndpoint}`;
    return this.http.get<Country[]>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public addCountry(country: Country): Observable<Country> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.addCountryEndpoint}`;
    return this.http.post<Country>(url, JSON.stringify(country)).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public deleteCountry(code: any): Observable<string> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.deleteCountryEndpoint}/${code}`;
    return this.http.delete<string>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }


  public getAllState(): Observable<State[]> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.getAllStateEndpoint}`;
    return this.http.get<State[]>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public addState(state: State): Observable<State> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.addStateEndpoint}`;
    return this.http.post<State>(url, JSON.stringify(state)).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public deleteState(code: any): Observable<string> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.deleteStateEndpoint}/${code}`;
    return this.http.delete<string>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }
 

  public getAllcity(): Observable<City[]> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.getAllCityEndpoint}`;
    return this.http.get<City[]>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public addCity(city: City): Observable<City> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.addCityEndpoint}`;
    return this.http.post<City>(url, JSON.stringify(city)).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public deleteCity(code: any): Observable<string> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.deleteCityEndpoint}/${code}`;
    return this.http.delete<string>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public getAllcovidinfo(): Observable<CovidInfo[]> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.getAllCovidInfoEndpoint}`;
    return this.http.get<CovidInfo[]>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public addcovidinfo(covidinfo: CovidInfo): Observable<CovidInfo> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.addCovidInfoEndpoint}`;
    return this.http.post<CovidInfo>(url, JSON.stringify(covidinfo)).pipe(map(this.extractResult), catchError(this.handleError));
  }

  public deletecovidInfo(code: any): Observable<string> {
    let url = `${this.GATEWAY_API_ROOT}/${Constants.deleteCovidInfoEndpoint}/${code}`;
    return this.http.delete<string>(url).pipe(map(this.extractResult), catchError(this.handleError));
  }

  private extractResult(result: any) {
    return result || {};
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent)
      console.error('An error occured', error.error.message);
    else
      console.error(`Backend returned code ${error.status}, body was: ${error.error}`);
    return throwError('Something bad happened; please try again.');
  }
}
