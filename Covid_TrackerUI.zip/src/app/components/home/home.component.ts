import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import * as moment from 'moment';
import * as _ from 'lodash';
import { combineLatest, of } from 'rxjs';
import { debounceTime, switchMap } from 'rxjs/operators';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { CompanyDetails, Stock, StockAddVM } from 'src/app/models/company.model';
import { FormvalidationService } from 'src/app/services/validators.service';
import { geographicService } from 'src/app/services/geographic.service';
import { ToastService } from 'src/app/services/toast.service';
import { IConfirmBoxPublicResponse } from '@costlydeveloper/ngx-awesome-popup';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, AfterViewInit {

  @ViewChild('tableEl', { static: false, read: MdbTableDirective }) mdbTable: MdbTableDirective;
  @ViewChild('stockDetails', { static: false, read: ModalDirective }) viewStockDetModal: ModalDirective;
  @ViewChild('stockTablePgn', { static: false, read: MdbTablePaginationComponent }) stockTablePgn: MdbTablePaginationComponent;
  @ViewChild('stockTableEl', { static: false, read: MdbTableDirective }) stockTableEl: MdbTableDirective;
  @ViewChild('addStock', { static: false, read: ModalDirective }) addStockModal: ModalDirective;
 
  constructor(private cdRef: ChangeDetectorRef,
    private router: Router,
    private fb: FormBuilder,
    private formValidatorService: FormvalidationService,
    private companyService: geographicService, private toastService: ToastService) {

  }
  ngAfterViewInit(): void {
   
  }

  ngOnInit(): void {
  }

  searchCompany() {

  }

  getFormattedNaN(val: any) {
    return isNaN(val) ? 0 : val;
  }

  getFormattedDate(val: any): any {
    return moment(val).format('MMMM Do YYYY');
  }

  getFormattedTime(val: any): any {
    return moment(val).format('h:mm:ss:SSS a');
  }
  
  private reloadCurrentRoute() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this.router.navigate([currentUrl]);
    });
  }

}
