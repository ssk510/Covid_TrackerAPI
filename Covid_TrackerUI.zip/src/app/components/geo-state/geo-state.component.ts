import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as _ from 'lodash';
import { State } from 'src/app/models/geographic.model';
import { geographicService } from 'src/app/services/geographic.service';

@Component({
  selector: 'app-geo-state',
  templateUrl: './geo-state.component.html',
  styleUrls: ['./geo-state.component.scss']
})
export class GeoStateComponent implements OnInit {
  @ViewChild('addState', { static: false, read: ModalDirective }) addStateModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addStateForm: FormGroup;
  countrylist: State[] = [];

  constructor(private fb: FormBuilder,private geoService:geographicService) { }

  ngOnInit(): void {
    this.createFormsAndEvents();
    this.geoService.getAllState().subscribe((stks: State[]) => {
      this.countrylist = stks || [];
    });
  }

  private createFormsAndEvents() {
    this.addStateForm = this.fb.group({
      stateName: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(20)]), updateOn: 'blur' }),
      country: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) })
    });
  }

  get addStateFormControl() {
    return this.addStateForm.controls;
  }

  add() {
    this.addStateForm.reset();
    this.addStateModal.show();
  }
 onSubmit() {

    if (this.addStateForm.valid) {
      const compDet: State = {
        Name: this.addStateForm.value.countryName,
        CountryId: this.addStateForm.value.country,
        IsActive:true
      };
      this.geoService.addState(compDet).subscribe((res: State) => {
        if (res) {
          console.log('State', `${compDet.Name} added successfully!`);
        }
        this.addStateForm.reset();
      });
      
    }
  }
}
