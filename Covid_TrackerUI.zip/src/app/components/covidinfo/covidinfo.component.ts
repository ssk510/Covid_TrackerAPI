import {AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MdbTableDirective, MdbTablePaginationComponent, ModalDirective } from 'angular-bootstrap-md';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import * as _ from 'lodash';
import { CovidInfo } from 'src/app/models/geographic.model';
import { geographicService } from 'src/app/services/geographic.service';

@Component({
  selector: 'app-covidinfo',
  templateUrl: './covidinfo.component.html',
  styleUrls: ['./covidinfo.component.scss']
})
export class CovidinfoComponent implements OnInit {
  @ViewChild('addCovidInfo', { static: false, read: ModalDirective }) addCovidInfoModal: ModalDirective;
  // @ViewChild('companyPagination', { static: true, read: MdbTablePaginationComponent }) mdbTablePagination: MdbTablePaginationComponent;
  stockCmpSelect = new FormControl(null, Validators.required);
  addCovidInfoForm: FormGroup;
  covidList: CovidInfo[] = [];

  constructor(private fb: FormBuilder,private geoService:geographicService) { }

  ngOnInit(): void {
    this.createFormsAndEvents();
    this.geoService.getAllcity().subscribe((stks: CovidInfo[]) => {
      this.covidList = stks || [];
    });
  }

  private createFormsAndEvents() {
    this.addCovidInfoForm = this.fb.group({
      country: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      state: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      city: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isTested: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isConfirmed: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isQuarantine: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isRecovered: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      isDeceased: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) }),
      dateTime: new FormControl(null, { validators: Validators.compose([Validators.required, Validators.maxLength(100)]) })
        });
  }

  get addCovidInfoFormControl() {
    return this.addCovidInfoForm.controls;
  }

  add() {
    this.addCovidInfoForm.reset();
    this.addCovidInfoModal.show();
  }
  onSubmit() {

    if (this.addCovidInfoForm.valid) {
      const compDet: CovidInfo = {
        Name: this.addCovidInfoForm.value.countryName,
        CountryId: this.addCovidInfoForm.value.country,
        StateId:this.addCovidInfoForm.value.state,
        IsActive:true
      };
      this.geoService.addcovidinfo(compDet).subscribe((res: CovidInfo) => {
        if (res) {
          console.log('CovidInfo', `${compDet.Name} added successfully!`);
        }
        this.addCovidInfoForm.reset();
      });
      
    }
  }

}
